# 📊 StockPilot AI

> Automated daily Indian stock market reports delivered straight to your Telegram — every weekday at **5:00 PM IST**, powered by GitHub Actions.

---

## ✨ What it does

Every weekday evening, StockPilot AI:

1. **Screens 50+ Nifty large-cap stocks** to find the top 4 closest to their **52-week highs** (momentum leaders) and top 4 closest to their **52-week lows** (potential reversals)
2. **Aggregates the latest Indian market headlines** from Economic Times, Moneycontrol, LiveMint, and Business Standard — no API key required
3. **Sends a beautifully formatted Telegram message** with all the data, including prices, day change %, sector, market cap, and clickable news links

---

## 📸 Sample Report

```
📊 StockPilot AI — Daily Market Report
🗓 Monday, 01 Jul 2024  •  🕔 05:00 PM IST
────────────────────────────────
🚀 TOP 4 STOCKS NEAR 52-WEEK HIGHS

1. RELIANCE — Reliance Industries Ltd
   💰 ₹2,987.50   🟢 +1.23%
   📈 52W High: ₹3,024.90  (1.24% below peak)
   🏢 Sector: Energy   Mkt Cap: ₹20.18L Cr

...

📉 TOP 4 STOCKS NEAR 52-WEEK LOWS
...

📰 LATEST INDIAN MARKET NEWS
• Nifty crosses 24,000 for the first time...
  — Economic Times
...
```

---

## 🚀 Setup Guide

### Prerequisites
- A GitHub account with a public or private repository
- A Telegram bot (create one via [@BotFather](https://t.me/BotFather))
- Your Telegram Chat ID (use [@userinfobot](https://t.me/userinfobot))

### Step 1 — Fork / clone this repo

```bash
git clone https://github.com/your-username/StockPilot-AI.git
cd StockPilot-AI
```

### Step 2 — Add GitHub Secrets

Go to your repo → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

| Secret name | Value |
|-------------|-------|
| `BOT_TOKEN` | Your Telegram bot token (e.g. `123456:ABC-DEF...`) |
| `CHAT_ID`   | Your Telegram chat/channel ID (e.g. `-1001234567890`) |

### Step 3 — Push to GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

The workflow runs automatically every weekday at **5:00 PM IST** (11:30 AM UTC).

### Step 4 — Test manually

Go to **Actions** tab → **StockPilot AI — Daily Market Report** → **Run workflow** → **Run workflow**

---

## 🗂 Project Structure

```
StockPilot-AI/
├── .github/
│   └── workflows/
│       └── daily.yml        # GitHub Actions schedule
├── main.py                  # Orchestrator entry point
├── stock_fetcher.py         # 52-week high/low screener (yfinance)
├── news_fetcher.py          # RSS news aggregator
├── telegram_sender.py       # Message formatter + Telegram API client
├── requirements.txt         # Python dependencies
├── .env.example             # Template for local development
├── .gitignore
└── README.md
```

---

## 🧪 Local Development

```bash
# 1. Create a virtual environment
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up environment variables
cp .env.example .env
# Edit .env and add your BOT_TOKEN and CHAT_ID

# 4. Run
python main.py
```

---

## ⚙️ Configuration

| File | What to change |
|------|---------------|
| `stock_fetcher.py` | Edit `NIFTY_UNIVERSE` to add/remove symbols; change `top_n` |
| `news_fetcher.py`  | Add/remove RSS sources in `RSS_SOURCES`; change `MAX_HEADLINES` |
| `.github/workflows/daily.yml` | Change cron schedule (currently `30 11 * * 1-5` = 5 PM IST weekdays) |

---

## 🔒 Security

- **Secrets are never hardcoded.** `BOT_TOKEN` and `CHAT_ID` are stored as GitHub Secrets and injected as environment variables at runtime.
- The `.env` file is in `.gitignore` and will never be committed.
- All HTTP requests use timeouts to prevent hanging.

---

## 📦 Dependencies

| Package | Purpose |
|---------|---------|
| `yfinance` | Fetch stock data from Yahoo Finance |
| `requests` | HTTP client for RSS feeds and Telegram API |
| `beautifulsoup4` | HTML/XML parsing |
| `pandas` | Data manipulation |
| `pytz` | IST timezone handling |
| `python-dotenv` | Load `.env` for local development |

---

## ⚠️ Disclaimer

This project is for **educational and informational purposes only**. Nothing in this report constitutes financial advice. Always do your own research before making investment decisions.

---

## 📄 License

MIT License — free to use, modify, and distribute.
