"""
telegram_sender.py
------------------
Formats and sends the daily StockPilot AI report via the Telegram Bot API.
Uses MarkdownV2 formatting for a rich, readable message layout.
"""

import logging
import re
from datetime import datetime
from typing import Optional

import pytz
import requests

logger = logging.getLogger(__name__)

TELEGRAM_API = "https://api.telegram.org/bot{token}/sendMessage"
REQUEST_TIMEOUT = 20  # seconds

IST = pytz.timezone("Asia/Kolkata")


def _escape_md(text: str) -> str:
    """
    Escape special characters for Telegram MarkdownV2.
    Required characters: _ * [ ] ( ) ~ ` > # + - = | { } . !
    """
    escape_chars = r"\_*[]()~`>#+-=|{}.!"
    return re.sub(f"([{re.escape(escape_chars)}])", r"\\\1", str(text))


def _format_change(pct: float) -> str:
    """Return an emoji + formatted percentage string for day change."""
    arrow = "🟢" if pct >= 0 else "🔴"
    sign = "+" if pct >= 0 else ""
    return f"{arrow} {sign}{pct:.2f}%"


def _format_market_cap(mc: Optional[float]) -> str:
    """Convert raw market cap (in ₹) to a human-friendly string."""
    if mc is None:
        return "N/A"
    if mc >= 1_00_000_00_00_000:   # 1 lakh crore
        return f"₹{mc / 1_00_000_00_00_000:.2f}L Cr"
    if mc >= 1_00_00_00_000:       # 1000 crore
        return f"₹{mc / 1_00_00_00_000:.2f}K Cr"
    return f"₹{mc / 1_00_00_000:.2f} Cr"


def build_message(near_high: list, near_low: list, news_items: list) -> str:
    """
    Construct the full Telegram MarkdownV2 message.

    Parameters
    ----------
    near_high : list[StockInfo]  — stocks closest to 52-week high
    near_low  : list[StockInfo]  — stocks closest to 52-week low
    news_items: list[NewsItem]   — latest market headlines
    """
    now_ist = datetime.now(IST)
    date_str = now_ist.strftime("%A, %d %b %Y")
    time_str = now_ist.strftime("%I:%M %p IST")

    lines: list[str] = []

    # ── Header ──────────────────────────────────────────────────────
    lines.append("📊 *StockPilot AI — Daily Market Report*")
    lines.append(f"🗓 {_escape_md(date_str)}  •  🕔 {_escape_md(time_str)}")
    lines.append("─" * 32)
    lines.append("")

    # ── Near 52-Week Highs ──────────────────────────────────────────
    lines.append("🚀 *TOP 4 STOCKS NEAR 52\\-WEEK HIGHS*")
    lines.append("")

    if near_high:
        for i, s in enumerate(near_high, 1):
            change_str = _format_change(s.day_change_pct)
            lines.append(
                f"*{i}\\. {_escape_md(s.symbol)}* — {_escape_md(s.name)}"
            )
            lines.append(
                f"   💰 ₹{_escape_md(s.current_price)}   {change_str}"
            )
            lines.append(
                f"   📈 52W High: ₹{_escape_md(s.week52_high)}  "
                f"\\({_escape_md(abs(s.pct_from_high))}% below peak\\)"
            )
            lines.append(
                f"   🏢 Sector: {_escape_md(s.sector)}   "
                f"Mkt Cap: {_escape_md(_format_market_cap(s.market_cap))}"
            )
            lines.append("")
    else:
        lines.append("_Data unavailable at this time\\._")
        lines.append("")

    # ── Near 52-Week Lows ───────────────────────────────────────────
    lines.append("─" * 32)
    lines.append("")
    lines.append("📉 *TOP 4 STOCKS NEAR 52\\-WEEK LOWS*")
    lines.append("")

    if near_low:
        for i, s in enumerate(near_low, 1):
            change_str = _format_change(s.day_change_pct)
            lines.append(
                f"*{i}\\. {_escape_md(s.symbol)}* — {_escape_md(s.name)}"
            )
            lines.append(
                f"   💰 ₹{_escape_md(s.current_price)}   {change_str}"
            )
            lines.append(
                f"   📉 52W Low: ₹{_escape_md(s.week52_low)}  "
                f"\\({_escape_md(s.pct_from_low)}% above bottom\\)"
            )
            lines.append(
                f"   🏢 Sector: {_escape_md(s.sector)}   "
                f"Mkt Cap: {_escape_md(_format_market_cap(s.market_cap))}"
            )
            lines.append("")
    else:
        lines.append("_Data unavailable at this time\\._")
        lines.append("")

    # ── Market News ─────────────────────────────────────────────────
    lines.append("─" * 32)
    lines.append("")
    lines.append("📰 *LATEST INDIAN MARKET NEWS*")
    lines.append("")

    if news_items:
        for item in news_items:
            bullet = f"• [{_escape_md(item.title[:90])}]({item.link})"
            lines.append(bullet)
            lines.append(f"  _— {_escape_md(item.source)}_")
            lines.append("")
    else:
        lines.append("_No news available at this time\\._")
        lines.append("")

    # ── Footer ──────────────────────────────────────────────────────
    lines.append("─" * 32)
    lines.append(
        "⚡ _Powered by StockPilot AI \\| Data: Yahoo Finance & public RSS_"
    )
    lines.append(
        "_⚠️ Not financial advice\\. Do your own research\\._"
    )

    return "\n".join(lines)


def send_telegram_message(bot_token: str, chat_id: str, message: str) -> bool:
    """
    Send a MarkdownV2 formatted message via the Telegram Bot API.

    Returns True on success, False on failure.
    """
    url = TELEGRAM_API.format(token=bot_token)
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "MarkdownV2",
        "disable_web_page_preview": True,
    }

    try:
        response = requests.post(url, json=payload, timeout=REQUEST_TIMEOUT)
        data = response.json()

        if response.ok and data.get("ok"):
            logger.info("✅ Telegram message sent successfully (message_id=%s)",
                        data.get("result", {}).get("message_id"))
            return True

        # Telegram returned an error even with HTTP 200
        logger.error(
            "Telegram API error %s: %s",
            data.get("error_code"),
            data.get("description"),
        )
        return False

    except requests.Timeout:
        logger.error("Telegram request timed out after %ds", REQUEST_TIMEOUT)
        return False
    except requests.RequestException as exc:
        logger.error("Failed to reach Telegram API: %s", exc)
        return False
