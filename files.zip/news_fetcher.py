"""
news_fetcher.py
---------------
Scrapes top Indian stock market headlines from publicly available RSS feeds.
Sources used (no API key required):
  1. Moneycontrol RSS
  2. Economic Times Markets RSS
  3. LiveMint Markets RSS

Falls back gracefully if any source is unavailable.
"""

import logging
import time
from dataclasses import dataclass
from typing import Optional
import xml.etree.ElementTree as ET

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# Free RSS / public XML feeds for Indian financial news
# ------------------------------------------------------------------
RSS_SOURCES = [
    {
        "name": "Economic Times",
        "url": "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",
        "type": "rss",
    },
    {
        "name": "Moneycontrol",
        "url": "https://www.moneycontrol.com/rss/marketreports.xml",
        "type": "rss",
    },
    {
        "name": "LiveMint",
        "url": "https://www.livemint.com/rss/markets",
        "type": "rss",
    },
    {
        "name": "Business Standard",
        "url": "https://www.business-standard.com/rss/markets-106.rss",
        "type": "rss",
    },
]

REQUEST_TIMEOUT = 12  # seconds
MAX_HEADLINES = 6     # total headlines to include in the report

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    )
}


@dataclass
class NewsItem:
    """A single news headline."""
    title: str
    link: str
    source: str
    pub_date: Optional[str] = None


def _parse_rss(content: bytes, source_name: str) -> list[NewsItem]:
    """Parse a standard RSS 2.0 XML feed and extract items."""
    items: list[NewsItem] = []
    try:
        root = ET.fromstring(content)
        # RSS items can be at root/channel/item
        ns = {"atom": "http://www.w3.org/2005/Atom"}
        channel = root.find("channel")
        entries = channel.findall("item") if channel is not None else root.findall(".//item")

        for entry in entries:
            title_el = entry.find("title")
            link_el = entry.find("link")
            date_el = entry.find("pubDate")

            if title_el is None or not title_el.text:
                continue

            title = title_el.text.strip()
            link = (link_el.text or "").strip() if link_el is not None else ""
            pub_date = date_el.text.strip() if date_el is not None else None

            if title:
                items.append(NewsItem(title=title, link=link, source=source_name, pub_date=pub_date))

    except ET.ParseError as exc:
        logger.warning("XML parse error for %s: %s", source_name, exc)

    return items


def _fetch_feed(source: dict) -> list[NewsItem]:
    """Fetch and parse a single RSS feed. Returns [] on any error."""
    try:
        resp = requests.get(source["url"], headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return _parse_rss(resp.content, source["name"])
    except requests.RequestException as exc:
        logger.warning("Could not fetch feed from %s: %s", source["name"], exc)
        return []


def get_top_market_news(max_items: int = MAX_HEADLINES) -> list[NewsItem]:
    """
    Aggregate headlines from multiple RSS sources.
    Deduplicates by title. Returns up to max_items NewsItem objects.
    """
    all_news: list[NewsItem] = []
    seen_titles: set[str] = set()

    for source in RSS_SOURCES:
        items = _fetch_feed(source)
        for item in items:
            # Simple dedup: normalise title to lower-case
            key = item.title.lower()[:80]
            if key not in seen_titles:
                seen_titles.add(key)
                all_news.append(item)

        # Stop early if we already have enough
        if len(all_news) >= max_items * 2:
            break

        time.sleep(0.5)  # be polite to servers

    if not all_news:
        logger.warning("No news fetched from any source")

    return all_news[:max_items]
