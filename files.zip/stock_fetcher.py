"""
stock_fetcher.py
----------------
Fetches top Indian stocks near their 52-week highs and lows using yfinance.
Screens a curated list of Nifty 50 / large-cap symbols and ranks them by
proximity to each extreme.
"""

import logging
from dataclasses import dataclass
from typing import Optional

import pandas as pd
import yfinance as yf

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------
# Curated universe: Nifty 50 + popular large-cap NSE symbols
# ------------------------------------------------------------------
NIFTY_UNIVERSE = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
    "HINDUNILVR.NS", "SBIN.NS", "BHARTIARTL.NS", "ITC.NS", "KOTAKBANK.NS",
    "LT.NS", "HCLTECH.NS", "AXISBANK.NS", "BAJFINANCE.NS", "ASIANPAINT.NS",
    "MARUTI.NS", "TITAN.NS", "SUNPHARMA.NS", "ULTRACEMCO.NS", "WIPRO.NS",
    "ONGC.NS", "POWERGRID.NS", "NTPC.NS", "M&M.NS", "TECHM.NS",
    "NESTLEIND.NS", "TATAMOTORS.NS", "TATASTEEL.NS", "ADANIENT.NS", "ADANIPORTS.NS",
    "BAJAJFINSV.NS", "DRREDDY.NS", "CIPLA.NS", "EICHERMOT.NS", "BPCL.NS",
    "COALINDIA.NS", "JSWSTEEL.NS", "GRASIM.NS", "HINDALCO.NS", "DIVISLAB.NS",
    "BRITANNIA.NS", "APOLLOHOSP.NS", "HEROMOTOCO.NS", "UPL.NS", "INDUSINDBK.NS",
    "BAJAJ-AUTO.NS", "TATACONSUM.NS", "LTIM.NS", "SBILIFE.NS", "HDFCLIFE.NS",
]


@dataclass
class StockInfo:
    """Holds key data points for a single stock."""
    symbol: str
    name: str
    current_price: float
    week52_high: float
    week52_low: float
    day_change_pct: float
    volume: int
    market_cap: Optional[float]
    pct_from_high: float   # negative means below high  (e.g. -3.2 → 3.2% below high)
    pct_from_low: float    # positive means above low   (e.g. 5.1 → 5.1% above low)
    sector: str


def _safe_get(info: dict, key: str, default=None):
    """Return info[key] or default — avoids KeyError / None crashes."""
    val = info.get(key)
    return val if val is not None else default


def fetch_stock_data(symbol: str) -> Optional[StockInfo]:
    """
    Download ticker metadata from Yahoo Finance for a single NSE symbol.
    Returns StockInfo or None on any error.
    """
    try:
        ticker = yf.Ticker(symbol)
        info = ticker.info

        current = _safe_get(info, "currentPrice") or _safe_get(info, "regularMarketPrice")
        high52 = _safe_get(info, "fiftyTwoWeekHigh")
        low52 = _safe_get(info, "fiftyTwoWeekLow")

        # Skip if essential fields are missing
        if not all([current, high52, low52]):
            logger.debug("Skipping %s — missing price data", symbol)
            return None

        if high52 == low52:
            logger.debug("Skipping %s — 52-week high equals low", symbol)
            return None

        prev_close = _safe_get(info, "regularMarketPreviousClose", current)
        day_change_pct = ((current - prev_close) / prev_close) * 100 if prev_close else 0.0

        pct_from_high = ((current - high52) / high52) * 100   # ≤ 0
        pct_from_low = ((current - low52) / low52) * 100      # ≥ 0

        return StockInfo(
            symbol=symbol.replace(".NS", ""),
            name=_safe_get(info, "longName") or _safe_get(info, "shortName") or symbol,
            current_price=round(current, 2),
            week52_high=round(high52, 2),
            week52_low=round(low52, 2),
            day_change_pct=round(day_change_pct, 2),
            volume=int(_safe_get(info, "volume", 0)),
            market_cap=_safe_get(info, "marketCap"),
            pct_from_high=round(pct_from_high, 2),
            pct_from_low=round(pct_from_low, 2),
            sector=_safe_get(info, "sector", "Unknown"),
        )

    except Exception as exc:
        logger.warning("Error fetching %s: %s", symbol, exc)
        return None


def get_top_stocks_near_extremes(top_n: int = 4) -> dict:
    """
    Screen the Nifty universe and return the stocks closest to their
    52-week highs and 52-week lows.

    Returns:
        {
            "near_high": [StockInfo, ...],   # top_n stocks closest to 52W high
            "near_low":  [StockInfo, ...],   # top_n stocks closest to 52W low
        }
    """
    logger.info("Fetching data for %d symbols …", len(NIFTY_UNIVERSE))
    stocks: list[StockInfo] = []

    for symbol in NIFTY_UNIVERSE:
        data = fetch_stock_data(symbol)
        if data:
            stocks.append(data)

    if not stocks:
        logger.error("No stock data retrieved — check network / API availability")
        return {"near_high": [], "near_low": []}

    logger.info("Successfully fetched %d / %d stocks", len(stocks), len(NIFTY_UNIVERSE))

    # Near 52-week HIGH → smallest absolute pct_from_high (closest to 0 from below)
    near_high = sorted(stocks, key=lambda s: abs(s.pct_from_high))[:top_n]

    # Near 52-week LOW → smallest pct_from_low (closest to 0 from above)
    near_low = sorted(stocks, key=lambda s: s.pct_from_low)[:top_n]

    return {"near_high": near_high, "near_low": near_low}
