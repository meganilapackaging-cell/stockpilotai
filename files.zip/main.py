"""
main.py
-------
StockPilot AI — Entry Point
Orchestrates data fetching, message building, and Telegram delivery.

Environment variables (set as GitHub Secrets):
    BOT_TOKEN — Telegram bot token  (e.g. 123456:ABC-DEF...)
    CHAT_ID   — Telegram chat / channel ID  (e.g. -1001234567890)
"""

import logging
import os
import sys
from datetime import datetime

import pytz
from dotenv import load_dotenv  # no-op when running in GitHub Actions

from stock_fetcher import get_top_stocks_near_extremes
from news_fetcher import get_top_market_news
from telegram_sender import build_message, send_telegram_message

# ── Logging setup ──────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("stockpilot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("stockpilot.main")

IST = pytz.timezone("Asia/Kolkata")


def load_config() -> tuple[str, str]:
    """
    Load BOT_TOKEN and CHAT_ID from environment.
    Supports both GitHub Actions secrets and a local .env file.
    Exits with a clear message if either is missing.
    """
    load_dotenv()  # picks up .env when running locally; silent in CI

    bot_token = os.getenv("BOT_TOKEN", "").strip()
    chat_id = os.getenv("CHAT_ID", "").strip()

    missing = []
    if not bot_token:
        missing.append("BOT_TOKEN")
    if not chat_id:
        missing.append("CHAT_ID")

    if missing:
        logger.critical(
            "Missing required environment variable(s): %s\n"
            "Set them as GitHub Secrets or in a local .env file.",
            ", ".join(missing),
        )
        sys.exit(1)

    return bot_token, chat_id


def is_market_day() -> bool:
    """
    Return True if today is a weekday (Mon–Fri) in IST.
    GitHub Actions cron already filters weekdays, but this guard
    protects manual workflow_dispatch runs on weekends.
    """
    now_ist = datetime.now(IST)
    return now_ist.weekday() < 5  # 0=Mon … 4=Fri


def main() -> None:
    logger.info("=" * 60)
    logger.info("StockPilot AI — starting run")
    logger.info("=" * 60)

    # ── Validate environment ───────────────────────────────────────
    bot_token, chat_id = load_config()

    if not is_market_day():
        logger.info("Today is a weekend in IST — skipping report.")
        return

    # ── Fetch stock data ───────────────────────────────────────────
    logger.info("Step 1/3 — Fetching stock data …")
    try:
        extremes = get_top_stocks_near_extremes(top_n=4)
    except Exception as exc:
        logger.exception("Unexpected error in stock fetcher: %s", exc)
        extremes = {"near_high": [], "near_low": []}

    near_high = extremes.get("near_high", [])
    near_low = extremes.get("near_low", [])
    logger.info(
        "Stocks near 52W high: %d   |   Stocks near 52W low: %d",
        len(near_high), len(near_low),
    )

    # ── Fetch market news ──────────────────────────────────────────
    logger.info("Step 2/3 — Fetching market news …")
    try:
        news_items = get_top_market_news(max_items=6)
    except Exception as exc:
        logger.exception("Unexpected error in news fetcher: %s", exc)
        news_items = []

    logger.info("Headlines fetched: %d", len(news_items))

    # ── Build & send Telegram message ─────────────────────────────
    logger.info("Step 3/3 — Sending Telegram report …")
    try:
        message = build_message(near_high, near_low, news_items)
    except Exception as exc:
        logger.exception("Error building message: %s", exc)
        sys.exit(1)

    success = send_telegram_message(bot_token, chat_id, message)

    if success:
        logger.info("✅ StockPilot AI run completed successfully.")
    else:
        logger.error("❌ Failed to deliver the Telegram message.")
        sys.exit(1)


if __name__ == "__main__":
    main()
